from fido2.webauthn import AuthenticatorAttachment as Attachment
