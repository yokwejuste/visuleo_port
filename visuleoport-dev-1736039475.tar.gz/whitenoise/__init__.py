from __future__ import annotations

from whitenoise.base import WhiteNoise

__all__ = ["WhiteNoise"]
